var searchData=
[
  ['end',['end',['../struct_xe_thru_1_1_detection_zone_limits.xhtml#a2aa52b7e6592214d3c2b70ba7f2d1efa',1,'XeThru::DetectionZoneLimits::end()'],['../struct_xe_thru_1_1_frame_area.xhtml#a1781bab977f4dda334e6ffe5dec9beed',1,'XeThru::FrameArea::end()'],['../struct_xe_thru_1_1_detection_zone.xhtml#a07d20550d083d6a7208a4ff8cacfcf1f',1,'XeThru::DetectionZone::end()']]],
  ['epoch',['epoch',['../struct_xe_thru_1_1_data_record.xhtml#a71dda349305fbf9090dc2e0b487fdeca',1,'XeThru::DataRecord']]]
];

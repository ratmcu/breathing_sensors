var searchData=
[
  ['abbreviations',['Abbreviations',['../abbreviations.xhtml',1,'']]]
];

var searchData=
[
  ['inject_5fframe',['inject_frame',['../class_xe_thru_1_1_x4_m200.xhtml#a7c8f4cc0afbc5dc33098fcc0298a6b2b',1,'XeThru::X4M200::inject_frame()'],['../class_xe_thru_1_1_x4_m300.xhtml#a2f8cb899e0d54623cdc530e50e1780f2',1,'XeThru::X4M300::inject_frame()']]],
  ['is_5fcsv_5fheader',['is_csv_header',['../struct_xe_thru_1_1_data_record.xhtml#a2bd8e37972f21ad20240f85686d68dd2',1,'XeThru::DataRecord']]],
  ['is_5fopen',['is_open',['../class_xe_thru_1_1_data_reader.xhtml#aca5f066bb4abf600cd15b4784a83b8ec',1,'XeThru::DataReader']]],
  ['is_5frecording',['is_recording',['../class_xe_thru_1_1_data_recorder.xhtml#a2f41cd9969ee450d4f657e5208fe173a',1,'XeThru::DataRecorder']]]
];
